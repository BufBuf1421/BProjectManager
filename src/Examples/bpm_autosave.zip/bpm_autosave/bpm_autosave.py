import os
from krita import Extension, Krita
from PyQt5.QtCore import QTimer, Qt

class BpmAutosave(Extension):
    def __init__(self, parent):
        super().__init__(parent)

    def setup(self):
        pass

    def createActions(self, window):
        # Передаём только путь к временному файлу, само окно получим позже
        QTimer.singleShot(2500, Qt.CoarseTimer, self._do_work)

    def _do_work(self):
        tmp_file = os.path.join(os.getcwd(), '.bpm_krita_target.txt')
        if not os.path.exists(tmp_file):
            return

        try:
            with open(tmp_file, 'r', encoding='utf-8') as f:
                target_path = f.read().strip()
        except Exception:
            return

        try:
            os.remove(tmp_file)
        except OSError:
            pass

        if not target_path:
            return

        app = Krita.instance()
        
        # Получаем актуальное активное окно в момент выполнения
        window = app.activeWindow()
        if window is None:
            return

        if app.activeDocument() is not None:
            return

        os.makedirs(os.path.dirname(target_path), exist_ok=True)

        doc = app.createDocument(1920, 1080, 'Untitled', 'RGBA', 'U8', '', 300.0)
        doc.setFileName(target_path)
        doc.save()
        window.addView(doc)

Krita.instance().addExtension(BpmAutosave(Krita.instance()))